import sys
import os
print("[-] Container is stopping: " + os.environ["NODE_NAME"], file=sys.stdout)